import java.util.ArrayList;
class Node{
  private Node up;
  private Node down;
  private Node left;
  private Node right;

  private Piece value;

  public Node(Piece e){
    value = e;
  }

  public boolean equals(Node k){
    if (k.getValue().equals(value)){
      return true;
    }else{
      return false;
    }
  }

  public String toString(){
    if (value == null){
      return "null";
    }else{
      return value.toString();
    }
  }

  public String print(){
    return "Value: " + value + "\nUp: " + up + "\nDown: " + down  +"\nLeft: " + left + "\nRight: " + right;
  }

  public void setUp(Node up){
    this.up = up;
  }

  public void setValue(Piece e){
    value = e;
  }

  public Piece getValue(){
    return value;
  }

  public void setDown(Node down){
    this.down = down;
  }

  public void setLeft(Node left){
    this.left = left;
  }

  public void setRight(Node right){
    this.right = right;
  }

  public Node getUp(){
    return up;
  }

  public Node getDown(){
    return down;
  }

  public Node getLeft(){
    return left;
  }

  public Node getRight(){
    return right;
  }

  public Node moveUp(){
    getUp().setValue(value);
    setValue(new Piece(" "));
    return getUp();
  }

  public Node moveDown(){
    getDown().setValue(value);
    setValue(new Piece(" "));
    return getDown();
  }

	public void moveUpRight(){
		moveRight();
		right.moveUp();
	}

	public void moveUpLeft(){
		moveLeft();
		left.moveUp();
	}

	public void moveDownLeft(){
		moveLeft();
		left.moveDown();
	}

	public void moveDownRight(){
		moveRight();
		right.moveDown();
	}

  public Node moveLeft(){
    getLeft().setValue(value);
    setValue(new Piece(" "));
    return getLeft();
  }

  public Node moveRight(){
    getRight().setValue(value);
    setValue(new Piece(" "));
    return getRight();
  }

	public ArrayList<Action> getMoves(String x){
		ArrayList<Action> returnArr = new ArrayList<Action>();
		if (value.getName().equals(x)){
			if (left != null && !(left.getValue().getName().equals(x)) && left.getValue() != null){
				returnArr.add(new Action(this, "left"));
			}
			if (right != null && !(right.getValue().getName().equals(x)) && right.getValue() != null){
				returnArr.add(new Action(this, "right"));
			}
			if (up != null && !(up.getValue().getName().equals(x)) && up.getValue() != null){
				returnArr.add(new Action(this, "up"));
				if (up.getRight() != null && !(up.getRight().getValue().getName().equals(x)) && up.getRight().getValue() != null){
						returnArr.add(new Action(this, "upright"));
				}if (up.getLeft() != null && !(up.getLeft().getValue().getName().equals(x)) && up.getLeft().getValue() != null){
					returnArr.add(new Action(this, "upleft"));
				}
			}
			if (down != null && !(down.getValue().getName().equals(x)) && down.getValue() != null){
				returnArr.add(new Action(this, "down"));
				if (down.getRight() != null && !(down.getRight().getValue().getName().equals(x)) && down.getRight().getValue() != null){
						returnArr.add(new Action(this, "downright"));
				}if (down.getLeft() != null && !(down.getLeft().getValue().getName().equals(x)) && down.getLeft().getValue() != null){
					returnArr.add(new Action(this, "downleft"));
				}
			}
		}
		return returnArr;
	}


}